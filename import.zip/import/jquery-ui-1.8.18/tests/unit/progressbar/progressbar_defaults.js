/*
 * progressbar_defaults.js
 */

var progressbar_defaults = {
	disabled: false,
	value: 0,
	max: 100
};

commonWidgetTests('progressbar', { defaults: progressbar_defaults });
